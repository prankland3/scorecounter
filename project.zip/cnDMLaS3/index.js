let home_el = document.getElementById("score-home")
let guest_el = document.getElementById("score-guest")
let result_home = 0
let result_guest = 0

function add_1_home(){
    result_home += 1
    home_el.textContent = result_home 
}

function add_2_home(){
    result_home += 2
    home_el.textContent = result_home  
}

function add_3_home(){
    result_home += 3
    home_el.textContent = result_home 
}

function add_1_guest(){
    result_guest += 1
    guest_el.textContent = result_guest 
}

function add_2_guest(){
    result_guest += 2
    guest_el.textContent = result_guest  
}

function add_3_guest(){
    result_guest += 3
    guest_el.textContent = result_guest  
}

function new_game(){
  result_home = 0
  result_guest = 0
  guest_el.textContent = result_guest  
  home_el.textContent = result_home 
  
}
